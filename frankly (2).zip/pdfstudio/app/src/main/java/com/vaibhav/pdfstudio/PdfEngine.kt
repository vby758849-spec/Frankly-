package com.vaibhav.pdfstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import java.io.File
import kotlin.math.max
import kotlin.math.min

/** Describes one page in the page manager: which source page, plus extra rotation. */
data class PageSpec(val sourceIndex: Int, val rotation: Int = 0)

class PdfEngine(private val context: Context) {

    init {
        PDFBoxResourceLoader.init(context.applicationContext)
    }

    // ---------- file helpers ----------

    /** Copy a content:// uri into app cache so renderer and PDFBox can open it. */
    fun importUri(uri: Uri, name: String = "doc_${System.nanoTime()}.pdf"): File {
        val out = File(context.cacheDir, name)
        context.contentResolver.openInputStream(uri)?.use { input ->
            out.outputStream().use { input.copyTo(it) }
        } ?: error("Cannot open file")
        return out
    }

    fun newTempFile(prefix: String = "out"): File =
        File(context.cacheDir, "${prefix}_${System.nanoTime()}.pdf")

    fun exportTo(file: File, uri: Uri) {
        context.contentResolver.openOutputStream(uri, "wt")?.use { out ->
            file.inputStream().use { it.copyTo(out) }
        } ?: error("Cannot write file")
    }

    // ---------- rendering ----------

    class Renderer(file: File) : AutoCloseable {
        private val fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        private val renderer = PdfRenderer(fd)
        val pageCount: Int get() = renderer.pageCount

        @Synchronized
        fun render(index: Int, targetWidth: Int): Bitmap {
            val page = renderer.openPage(index)
            try {
                val scale = targetWidth.toFloat() / page.width
                val h = (page.height * scale).toInt().coerceAtLeast(1)
                val bmp = Bitmap.createBitmap(targetWidth, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                return bmp
            } finally {
                page.close()
            }
        }

        override fun close() {
            renderer.close()
            fd.close()
        }
    }

    // ---------- annotations: bake into PDF ----------

    fun saveWithAnnotations(src: File, annots: List<Annot>, dest: File) {
        PDDocument.load(src).use { doc ->
            val byPage = annots.groupBy { it.page }
            for ((pageIndex, list) in byPage) {
                if (pageIndex !in 0 until doc.numberOfPages) continue
                val page = doc.getPage(pageIndex)
                val box = page.mediaBox
                val w = box.width
                val h = box.height
                val ox = box.lowerLeftX
                val oy = box.lowerLeftY
                fun px(n: Float) = ox + n * w
                fun py(n: Float) = oy + (1f - n) * h

                PDPageContentStream(
                    doc, page, PDPageContentStream.AppendMode.APPEND, true, true
                ).use { cs ->
                    for (a in list) {
                        when (a) {
                            is Annot.Highlight -> {
                                val gs = PDExtendedGraphicsState().apply { setNonStrokingAlphaConstant(0.4f) }
                                cs.saveGraphicsState()
                                cs.setGraphicsStateParameters(gs)
                                cs.setNonStrokingColor(Color.red(a.color), Color.green(a.color), Color.blue(a.color))
                                val l = min(a.x1, a.x2); val r = max(a.x1, a.x2)
                                val t = min(a.y1, a.y2); val b = max(a.y1, a.y2)
                                cs.addRect(px(l), py(b), (r - l) * w, (b - t) * h)
                                cs.fill()
                                cs.restoreGraphicsState()
                            }
                            is Annot.Ink -> {
                                if (a.points.size < 2) continue
                                cs.saveGraphicsState()
                                cs.setStrokingColor(Color.red(a.color), Color.green(a.color), Color.blue(a.color))
                                cs.setLineWidth(a.width)
                                cs.setLineCapStyle(1)
                                cs.setLineJoinStyle(1)
                                cs.moveTo(px(a.points[0].x), py(a.points[0].y))
                                for (i in 1 until a.points.size) {
                                    cs.lineTo(px(a.points[i].x), py(a.points[i].y))
                                }
                                cs.stroke()
                                cs.restoreGraphicsState()
                            }
                            is Annot.Text -> drawText(cs, a.text, px(a.x), py(a.y) - a.size, a.size, a.color)
                            is Annot.Whiteout -> {
                                val l = min(a.x1, a.x2); val r = max(a.x1, a.x2)
                                val t = min(a.y1, a.y2); val b = max(a.y1, a.y2)
                                cs.saveGraphicsState()
                                cs.setNonStrokingColor(255, 255, 255)
                                cs.addRect(px(l), py(b), (r - l) * w, (b - t) * h)
                                cs.fill()
                                cs.restoreGraphicsState()
                                if (a.replacement.isNotBlank()) {
                                    drawText(cs, a.replacement, px(l) + 1f, py(b) + 2f, a.size, Color.BLACK)
                                }
                            }
                            is Annot.Image -> {
                                val img = LosslessFactory.createFromImage(doc, a.bitmap)
                                val l = min(a.x1, a.x2); val r = max(a.x1, a.x2)
                                val t = min(a.y1, a.y2); val b = max(a.y1, a.y2)
                                cs.drawImage(img, px(l), py(b), (r - l) * w, (b - t) * h)
                            }
                        }
                    }
                }
            }
            doc.save(dest)
        }
    }

    private fun drawText(cs: PDPageContentStream, text: String, x: Float, y: Float, size: Float, color: Int) {
        // Standard 14 fonts only support Latin; drop anything else to avoid crashes.
        val safe = text.filter { it.code in 32..255 || it == '\n' }
        var yy = y
        cs.setNonStrokingColor(Color.red(color), Color.green(color), Color.blue(color))
        for (line in safe.split('\n')) {
            cs.beginText()
            cs.setFont(PDType1Font.HELVETICA, size)
            cs.newLineAtOffset(x, yy)
            cs.showText(line)
            cs.endText()
            yy -= size * 1.2f
        }
    }
}
