package com.vaibhav.pdfstudio

import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDCheckBox
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDTextField
import java.io.File

/** Merge several PDFs, in order, into dest. */
fun PdfEngine.merge(sources: List<File>, dest: File) {
    val opened = mutableListOf<PDDocument>()
    try {
        PDDocument().use { out ->
            for (f in sources) {
                val src = PDDocument.load(f)
                opened.add(src)
                for (page in src.pages) out.importPage(page)
            }
            out.save(dest)
        }
    } finally {
        opened.forEach { runCatching { it.close() } }
    }
}

/** Rebuild a PDF from the given page specs: reorder, delete (omit) and rotate. */
fun PdfEngine.rebuildPages(src: File, specs: List<PageSpec>, dest: File) {
    PDDocument.load(src).use { source ->
        PDDocument().use { out ->
            for (spec in specs) {
                val page = source.getPage(spec.sourceIndex)
                val imported = out.importPage(page)
                imported.rotation = ((page.rotation + spec.rotation) % 360 + 360) % 360
            }
            out.save(dest)
        }
    }
}

/** Split: keep only pages in [from, to] (0-based, inclusive). */
fun PdfEngine.extractRange(src: File, from: Int, to: Int, dest: File) {
    val specs = (from..to).map { PageSpec(it) }
    rebuildPages(src, specs, dest)
}

fun PdfEngine.pageCountOf(src: File): Int =
    PDDocument.load(src).use { it.numberOfPages }

// ---------- forms ----------

fun PdfEngine.listFormFields(src: File): List<FormFieldInfo> {
    PDDocument.load(src).use { doc ->
        val form = doc.documentCatalog.acroForm ?: return emptyList()
        return form.fieldTree.mapNotNull { f ->
            when (f) {
                is PDTextField -> FormFieldInfo(f.fullyQualifiedName, "text", f.value ?: "")
                is PDCheckBox -> FormFieldInfo(f.fullyQualifiedName, "checkbox", if (f.isChecked) "true" else "false")
                else -> null
            }
        }
    }
}

fun PdfEngine.fillFormFields(src: File, values: Map<String, String>, dest: File) {
    PDDocument.load(src).use { doc ->
        val form = doc.documentCatalog.acroForm
        if (form != null) {
            form.setNeedAppearances(true)
            for ((name, value) in values) {
                when (val f = form.getField(name)) {
                    is PDTextField -> f.value = value
                    is PDCheckBox -> if (value == "true") f.check() else f.unCheck()
                    else -> {}
                }
            }
        }
        doc.save(dest)
    }
}
