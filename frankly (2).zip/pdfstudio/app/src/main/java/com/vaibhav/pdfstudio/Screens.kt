package com.vaibhav.pdfstudio

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.border
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScreens(
    vm: EditorViewModel,
    onOpen: () -> Unit,
    onSave: () -> Unit,
    onMerge: () -> Unit,
    onPickImage: () -> Unit
) {
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) {
        vm.message?.let { snackbar.showSnackbar(it); vm.message = null }
    }

    var showPages by remember { mutableStateOf(false) }
    var showForm by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (vm.file == null) "Frankly" else vm.displayName,
                        maxLines = 1
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                ),
                actions = {
                    if (vm.file != null) {
                        IconButton(onClick = { vm.undo() }, enabled = vm.canUndo) {
                            Icon(Icons.AutoMirrored.Filled.Undo, "Undo")
                        }
                        IconButton(onClick = { vm.redo() }, enabled = vm.canRedo) {
                            Icon(Icons.AutoMirrored.Filled.Redo, "Redo")
                        }
                        IconButton(onClick = onSave) { Icon(Icons.Filled.Save, "Save") }
                        Box {
                            IconButton(onClick = { menuOpen = true }) { Icon(Icons.Filled.MoreVert, "More") }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(text = { Text("Open another PDF") }, onClick = { menuOpen = false; onOpen() })
                                DropdownMenuItem(text = { Text("Pages (reorder/delete/rotate)") }, onClick = { menuOpen = false; showPages = true })
                                DropdownMenuItem(text = { Text("Merge PDFs") }, onClick = { menuOpen = false; onMerge() })
                                DropdownMenuItem(text = { Text("Fill form") }, onClick = { menuOpen = false; vm.loadForm(); showForm = true })
                            }
                        }
                    }
                }
            )
        },
        bottomBar = { if (vm.file != null) ToolBar(vm, onPickImage) }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            if (vm.file == null) {
                Home(onOpen)
            } else {
                Viewer(vm)
            }
            if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
        }
    }

    if (showPages) PageManagerDialog(vm, onClose = { showPages = false })
    if (showForm) FormDialog(vm, onClose = { showForm = false })
}

@Composable
private fun Home(onOpen: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Frankly", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "View, annotate, edit, merge aur sign karo",
            color = Color.Gray
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onOpen) { Text("PDF kholo") }
    }
}

@Composable
private fun Viewer(vm: EditorViewModel) {
    LazyColumn(
        Modifier.fillMaxSize().background(Color(0xFFCFD8DC)),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(8.dp)
    ) {
        items(vm.pageCount, key = { "${vm.version}-$it" }) { i ->
            PageView(vm, i)
        }
    }
}

@Composable
private fun ToolBar(vm: EditorViewModel, onPickImage: () -> Unit) {
    Column(Modifier.background(Color.White)) {
        if (vm.tool == Tool.DRAW || vm.tool == Tool.TEXT) {
            val colors = listOf(0xFFD32F2F, 0xFF1976D2, 0xFF388E3C, 0xFF000000, 0xFFF57C00)
            Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                colors.forEach { c ->
                    val argb = c.toInt()
                    Box(
                        Modifier.size(28.dp).clip(CircleShape).background(Color(argb))
                            .border(if (vm.penColor == argb) 3.dp else 0.dp, Color.Gray, CircleShape)
                            .clickable { vm.penColor = argb }
                    )
                }
            }
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ToolChip(vm, Tool.NONE, "Scroll")
            ToolChip(vm, Tool.HIGHLIGHT, "Highlight")
            ToolChip(vm, Tool.DRAW, "Draw")
            ToolChip(vm, Tool.TEXT, "Text")
            ToolChip(vm, Tool.WHITEOUT, "Edit text")
            FilterChip(
                selected = vm.tool == Tool.IMAGE,
                onClick = onPickImage,
                label = { Text("Image") }
            )
            ToolChip(vm, Tool.SIGN, "Sign")
        }
    }
}

@Composable
private fun ToolChip(vm: EditorViewModel, tool: Tool, label: String) {
    FilterChip(
        selected = vm.tool == tool,
        onClick = { vm.tool = tool },
        label = { Text(label) }
    )
}

@Composable
private fun PageManagerDialog(vm: EditorViewModel, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Pages (${vm.pageSpecs.size})") },
        text = {
            LazyColumn(Modifier.height(380.dp)) {
                itemsIndexed(vm.pageSpecs) { i, spec ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Page ${spec.sourceIndex + 1}" + if (spec.rotation != 0) "  (${spec.rotation}°)" else "",
                            Modifier.weight(1f)
                        )
                        IconButton(onClick = { vm.movePage(i, i - 1) }, enabled = i > 0) {
                            Icon(Icons.Filled.ArrowUpward, "Up")
                        }
                        IconButton(onClick = { vm.movePage(i, i + 1) }, enabled = i < vm.pageSpecs.lastIndex) {
                            Icon(Icons.Filled.ArrowDownward, "Down")
                        }
                        IconButton(onClick = { vm.rotatePage(i) }) { Icon(Icons.Filled.RotateRight, "Rotate") }
                        IconButton(onClick = { vm.deletePage(i) }) { Icon(Icons.Filled.Delete, "Delete") }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.applyPages(); onClose() }) { Text("Apply") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

@Composable
private fun FormDialog(vm: EditorViewModel, onClose: () -> Unit) {
    val values = remember { mutableStateMapOf<String, String>() }
    LaunchedEffect(vm.formFields.size) {
        vm.formFields.forEach { if (it.name !in values) values[it.name] = it.value }
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Form fill") },
        text = {
            if (vm.formFields.isEmpty()) {
                Text("Fields dhoondh raha hoon... (ya is PDF me form nahi hai)")
            } else {
                LazyColumn(Modifier.height(380.dp)) {
                    items(vm.formFields.toList()) { f ->
                        if (f.type == "checkbox") {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = values[f.name] == "true",
                                    onCheckedChange = { values[f.name] = it.toString() }
                                )
                                Text(f.name)
                            }
                        } else {
                            OutlinedTextField(
                                value = values[f.name] ?: "",
                                onValueChange = { values[f.name] = it },
                                label = { Text(f.name) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { vm.applyForm(values.toMap()); onClose() },
                enabled = vm.formFields.isNotEmpty()
            ) { Text("Apply") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}
