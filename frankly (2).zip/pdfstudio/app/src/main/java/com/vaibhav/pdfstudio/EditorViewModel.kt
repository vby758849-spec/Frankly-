package com.vaibhav.pdfstudio

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    val engine = PdfEngine(app)

    // current document
    var file by mutableStateOf<File?>(null); private set
    var pageCount by mutableIntStateOf(0); private set
    /** Bumps whenever the underlying file changes so page bitmaps re-render. */
    var version by mutableIntStateOf(0); private set
    var displayName by mutableStateOf("")

    // editing state
    val annots = mutableStateListOf<Annot>()
    private val undone = mutableStateListOf<Annot>()
    var tool by mutableStateOf(Tool.NONE)
    var penColor by mutableIntStateOf(0xFFD32F2F.toInt())
    var pendingImage by mutableStateOf<Bitmap?>(null)

    // ui state
    var busy by mutableStateOf(false); private set
    var message by mutableStateOf<String?>(null)

    // page manager / forms
    val pageSpecs = mutableStateListOf<PageSpec>()
    val formFields = mutableStateListOf<FormFieldInfo>()

    private var renderer: PdfEngine.Renderer? = null

    // ---------- open / reload ----------

    fun open(uri: Uri, name: String) {
        launchWork("Open nahi ho paya") {
            val f = withContext(Dispatchers.IO) { engine.importUri(uri) }
            annots.clear(); undone.clear()
            displayName = name
            setFile(f)
        }
    }

    private suspend fun setFile(f: File) {
        val r = withContext(Dispatchers.IO) { PdfEngine.Renderer(f) }
        renderer?.close()
        renderer = r
        file = f
        pageCount = r.pageCount
        version++
        pageSpecs.clear()
        pageSpecs.addAll((0 until r.pageCount).map { PageSpec(it) })
    }

    suspend fun renderPage(index: Int, width: Int): Bitmap? = withContext(Dispatchers.IO) {
        try { renderer?.render(index, width) } catch (e: Exception) { null }
    }

    // ---------- annotation edits ----------

    fun add(a: Annot) { annots.add(a); undone.clear() }

    fun undo() {
        if (annots.isNotEmpty()) undone.add(annots.removeAt(annots.lastIndex))
    }

    fun redo() {
        if (undone.isNotEmpty()) annots.add(undone.removeAt(undone.lastIndex))
    }

    val canUndo get() = annots.isNotEmpty()
    val canRedo get() = undone.isNotEmpty()

    /** Bake pending annotations into the file so other operations see them. */
    private suspend fun commitInternal() {
        val src = file ?: return
        if (annots.isEmpty()) return
        val out = engine.newTempFile("edit")
        withContext(Dispatchers.IO) { engine.saveWithAnnotations(src, annots.toList(), out) }
        annots.clear(); undone.clear()
        setFile(out)
    }

    // ---------- save ----------

    fun saveTo(uri: Uri) {
        launchWork("Save nahi ho paya") {
            commitInternal()
            val f = file ?: return@launchWork
            withContext(Dispatchers.IO) { engine.exportTo(f, uri) }
            message = "Save ho gaya"
        }
    }

    // ---------- pages ----------

    fun movePage(from: Int, to: Int) {
        if (from !in pageSpecs.indices || to !in pageSpecs.indices) return
        pageSpecs.add(to, pageSpecs.removeAt(from))
    }

    fun deletePage(i: Int) {
        if (pageSpecs.size > 1 && i in pageSpecs.indices) pageSpecs.removeAt(i)
    }

    fun rotatePage(i: Int) {
        if (i in pageSpecs.indices) {
            val s = pageSpecs[i]
            pageSpecs[i] = s.copy(rotation = (s.rotation + 90) % 360)
        }
    }

    fun applyPages() {
        launchWork("Pages apply nahi hue") {
            commitInternal()
            val src = file ?: return@launchWork
            val out = engine.newTempFile("pages")
            withContext(Dispatchers.IO) { engine.rebuildPages(src, pageSpecs.toList(), out) }
            setFile(out)
            message = "Pages update ho gaye"
        }
    }

    // ---------- merge ----------

    fun mergeWith(uris: List<Uri>) {
        launchWork("Merge nahi ho paya") {
            commitInternal()
            val base = file ?: return@launchWork
            val extra = withContext(Dispatchers.IO) { uris.map { engine.importUri(it) } }
            val out = engine.newTempFile("merged")
            withContext(Dispatchers.IO) { engine.merge(listOf(base) + extra, out) }
            setFile(out)
            message = "${uris.size} file(s) merge ho gayi"
        }
    }

    // ---------- forms ----------

    fun loadForm() {
        launchWork("Form nahi padha ja paya") {
            commitInternal()
            val f = file ?: return@launchWork
            val fields = withContext(Dispatchers.IO) { engine.listFormFields(f) }
            formFields.clear(); formFields.addAll(fields)
            if (fields.isEmpty()) message = "Is PDF me fillable form fields nahi hain"
        }
    }

    fun applyForm(values: Map<String, String>) {
        launchWork("Form fill nahi hua") {
            val f = file ?: return@launchWork
            val out = engine.newTempFile("form")
            withContext(Dispatchers.IO) { engine.fillFormFields(f, values, out) }
            setFile(out)
            message = "Form fill ho gaya"
        }
    }

    // ---------- helper ----------

    private fun launchWork(errorText: String, block: suspend () -> Unit) {
        viewModelScope.launch {
            busy = true
            try { block() } catch (e: Exception) {
                message = "$errorText: ${e.message ?: e.javaClass.simpleName}"
            } finally { busy = false }
        }
    }

    override fun onCleared() {
        renderer?.close()
    }
}
