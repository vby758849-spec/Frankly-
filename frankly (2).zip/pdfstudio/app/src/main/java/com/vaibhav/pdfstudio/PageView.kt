package com.vaibhav.pdfstudio

import android.graphics.Paint
import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.Canvas
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlin.math.max
import kotlin.math.min

private const val SIGN_COLOR = 0xFF0D47A1.toInt()

@Composable
fun PageView(vm: EditorViewModel, index: Int) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val widthPx = with(LocalDensity.current) { maxWidth.roundToPx() }
        val bitmap by produceState<Bitmap?>(null, vm.version, index, widthPx) {
            value = vm.renderPage(index, widthPx)
        }
        val bmp = bitmap
        if (bmp == null) {
            Box(Modifier.fillMaxWidth().aspectRatio(0.707f).background(Color.White))
            return@BoxWithConstraints
        }

        val tool = vm.tool
        var dragStart by remember { mutableStateOf<Offset?>(null) }
        var dragEnd by remember { mutableStateOf<Offset?>(null) }
        var stroke by remember { mutableStateOf<List<Offset>>(emptyList()) }
        var size by remember { mutableStateOf(Size(1f, 1f)) }
        var textAt by remember { mutableStateOf<Offset?>(null) }
        var whiteRect by remember { mutableStateOf<Pair<Offset, Offset>?>(null) }

        fun nx(o: Offset) = (o.x / size.width).coerceIn(0f, 1f)
        fun ny(o: Offset) = (o.y / size.height).coerceIn(0f, 1f)

        Box(Modifier.fillMaxWidth().aspectRatio(bmp.width.toFloat() / bmp.height)) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.matchParentSize(),
                contentScale = ContentScale.FillBounds
            )

            val gestureModifier = when (tool) {
                Tool.NONE -> Modifier
                Tool.TEXT -> Modifier.pointerInput(tool) {
                    detectTapGestures { textAt = it }
                }
                Tool.DRAW, Tool.SIGN -> Modifier.pointerInput(tool, vm.penColor) {
                    detectDragGestures(
                        onDragStart = { stroke = listOf(it) },
                        onDrag = { change, _ -> stroke = stroke + change.position },
                        onDragEnd = {
                            if (stroke.size > 1) {
                                val color = if (tool == Tool.SIGN) SIGN_COLOR else vm.penColor
                                vm.add(
                                    Annot.Ink(
                                        index,
                                        stroke.map { NPoint(nx(it), ny(it)) },
                                        color,
                                        if (tool == Tool.SIGN) 2.5f else 2f
                                    )
                                )
                            }
                            stroke = emptyList()
                        },
                        onDragCancel = { stroke = emptyList() }
                    )
                }
                else -> Modifier.pointerInput(tool) {
                    detectDragGestures(
                        onDragStart = { dragStart = it; dragEnd = it },
                        onDrag = { change, _ -> dragEnd = change.position },
                        onDragEnd = {
                            val s = dragStart; val e = dragEnd
                            if (s != null && e != null) {
                                when (tool) {
                                    Tool.HIGHLIGHT -> vm.add(Annot.Highlight(index, nx(s), ny(s), nx(e), ny(e), 0xFFFFEB3B.toInt()))
                                    Tool.WHITEOUT -> whiteRect = s to e
                                    Tool.IMAGE -> vm.pendingImage?.let {
                                        vm.add(Annot.Image(index, nx(s), ny(s), nx(e), ny(e), it))
                                    }
                                    else -> {}
                                }
                            }
                            dragStart = null; dragEnd = null
                        },
                        onDragCancel = { dragStart = null; dragEnd = null }
                    )
                }
            }

            Canvas(
                Modifier
                    .matchParentSize()
                    .then(gestureModifier)
            ) {
                size = this.size
                for (a in vm.annots) if (a.page == index) drawAnnot(a)

                // live previews
                val s = dragStart; val e = dragEnd
                if (s != null && e != null) {
                    val color = when (tool) {
                        Tool.HIGHLIGHT -> Color(0x66FFEB3B)
                        Tool.WHITEOUT -> Color(0xAAFFFFFF)
                        else -> Color(0x330000FF)
                    }
                    drawRect(color, Offset(min(s.x, e.x), min(s.y, e.y)), Size(kotlin.math.abs(e.x - s.x), kotlin.math.abs(e.y - s.y)))
                    drawRect(Color.Gray, Offset(min(s.x, e.x), min(s.y, e.y)), Size(kotlin.math.abs(e.x - s.x), kotlin.math.abs(e.y - s.y)), style = Stroke(1f))
                }
                if (stroke.size > 1) {
                    val p = Path().apply {
                        moveTo(stroke[0].x, stroke[0].y)
                        stroke.drop(1).forEach { lineTo(it.x, it.y) }
                    }
                    val c = if (tool == Tool.SIGN) Color(SIGN_COLOR) else Color(vm.penColor)
                    drawPath(p, c, style = Stroke(width = 4f))
                }
            }
        }

        // add-text dialog
        textAt?.let { pos ->
            var text by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { textAt = null },
                title = { Text("Text likho") },
                text = { OutlinedTextField(text, { text = it }, placeholder = { Text("Yahan text") }) },
                confirmButton = {
                    TextButton(onClick = {
                        if (text.isNotBlank()) vm.add(Annot.Text(index, nx(pos), ny(pos), text, 14f, vm.penColor))
                        textAt = null
                    }) { Text("Add") }
                },
                dismissButton = { TextButton(onClick = { textAt = null }) { Text("Cancel") } }
            )
        }

        // whiteout + replace dialog
        whiteRect?.let { (s, e) ->
            var text by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { whiteRect = null },
                title = { Text("Text replace karo") },
                text = {
                    OutlinedTextField(
                        text, { text = it },
                        placeholder = { Text("Naya text (khali = sirf mita do)") }
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        vm.add(Annot.Whiteout(index, nx(s), ny(s), nx(e), ny(e), text, 12f))
                        whiteRect = null
                    }) { Text("Apply") }
                },
                dismissButton = { TextButton(onClick = { whiteRect = null }) { Text("Cancel") } }
            )
        }
    }
}

private fun DrawScope.drawAnnot(a: Annot) {
    val w = size.width
    val h = size.height
    val scale = w / 595f // preview scale, assuming roughly A4 width in points
    when (a) {
        is Annot.Highlight -> {
            val l = min(a.x1, a.x2) * w; val t = min(a.y1, a.y2) * h
            drawRect(Color(a.color).copy(alpha = 0.4f), Offset(l, t),
                Size(kotlin.math.abs(a.x2 - a.x1) * w, kotlin.math.abs(a.y2 - a.y1) * h))
        }
        is Annot.Ink -> {
            if (a.points.size > 1) {
                val p = Path().apply {
                    moveTo(a.points[0].x * w, a.points[0].y * h)
                    for (i in 1 until a.points.size) lineTo(a.points[i].x * w, a.points[i].y * h)
                }
                drawPath(p, Color(a.color), style = Stroke(width = a.width * scale))
            }
        }
        is Annot.Text -> drawIntoCanvas { c ->
            val paint = Paint().apply {
                color = a.color; textSize = a.size * scale; isAntiAlias = true
            }
            var y = a.y * h + a.size * scale
            for (line in a.text.split('\n')) {
                c.nativeCanvas.drawText(line, a.x * w, y, paint)
                y += a.size * scale * 1.2f
            }
        }
        is Annot.Whiteout -> {
            val l = min(a.x1, a.x2) * w; val t = min(a.y1, a.y2) * h
            val bw = kotlin.math.abs(a.x2 - a.x1) * w; val bh = kotlin.math.abs(a.y2 - a.y1) * h
            drawRect(Color.White, Offset(l, t), Size(bw, bh))
            if (a.replacement.isNotBlank()) drawIntoCanvas { c ->
                val paint = Paint().apply { color = android.graphics.Color.BLACK; textSize = a.size * scale; isAntiAlias = true }
                c.nativeCanvas.drawText(a.replacement, l + 1f, t + bh - 2f * scale, paint)
            }
        }
        is Annot.Image -> {
            val l = min(a.x1, a.x2) * w; val t = min(a.y1, a.y2) * h
            val bw = (kotlin.math.abs(a.x2 - a.x1) * w).toInt().coerceAtLeast(1)
            val bh = (kotlin.math.abs(a.y2 - a.y1) * h).toInt().coerceAtLeast(1)
            drawImage(a.bitmap.asImageBitmap(), dstOffset = IntOffset(l.toInt(), t.toInt()), dstSize = IntSize(bw, bh))
        }
    }
}
