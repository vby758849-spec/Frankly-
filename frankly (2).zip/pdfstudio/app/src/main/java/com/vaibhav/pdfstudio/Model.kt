package com.vaibhav.pdfstudio

import android.graphics.Bitmap

/** All coordinates are normalized 0..1 from the top-left of the page. */
data class NPoint(val x: Float, val y: Float)

sealed class Annot {
    abstract val page: Int

    data class Highlight(
        override val page: Int,
        val x1: Float, val y1: Float, val x2: Float, val y2: Float,
        val color: Int = 0xFFFFEB3B.toInt()
    ) : Annot()

    data class Ink(
        override val page: Int,
        val points: List<NPoint>,
        val color: Int = 0xFFD32F2F.toInt(),
        val width: Float = 2f
    ) : Annot()

    data class Text(
        override val page: Int,
        val x: Float, val y: Float,
        val text: String,
        val size: Float = 14f,
        val color: Int = 0xFF000000.toInt()
    ) : Annot()

    /** Covers existing content with white; optional replacement text drawn on top. */
    data class Whiteout(
        override val page: Int,
        val x1: Float, val y1: Float, val x2: Float, val y2: Float,
        val replacement: String = "",
        val size: Float = 12f
    ) : Annot()

    data class Image(
        override val page: Int,
        val x1: Float, val y1: Float, val x2: Float, val y2: Float,
        val bitmap: Bitmap
    ) : Annot()
}

enum class Tool { NONE, HIGHLIGHT, DRAW, TEXT, WHITEOUT, IMAGE, SIGN }

data class FormFieldInfo(
    val name: String,
    val type: String,      // "text" or "checkbox"
    val value: String
)
