package com.vaibhav.pdfstudio

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {

    private val vm: EditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) handleIntent(intent)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFFC62828),
                    secondary = Color(0xFF37474F)
                )
            ) {
                AppRoot()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        val data = i?.data ?: return
        if (i.action == Intent.ACTION_VIEW) vm.open(data, nameOf(data))
    }

    private fun nameOf(uri: Uri): String =
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
        } ?: "document.pdf"

    @Composable
    private fun AppRoot() {
        val openPdf = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) vm.open(uri, nameOf(uri))
        }
        val savePdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
            if (uri != null) vm.saveTo(uri)
        }
        val pickMerge = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) vm.mergeWith(uris)
        }
        val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                contentResolver.openInputStream(uri)?.use { s ->
                    vm.pendingImage = BitmapFactory.decodeStream(s)
                    vm.tool = Tool.IMAGE
                }
            }
        }

        AppScreens(
            vm = vm,
            onOpen = { openPdf.launch(arrayOf("application/pdf")) },
            onSave = {
                val base = vm.displayName.removeSuffix(".pdf").ifBlank { "document" }
                savePdf.launch("${base}_edited.pdf")
            },
            onMerge = { pickMerge.launch(arrayOf("application/pdf")) },
            onPickImage = { pickImage.launch("image/*") }
        )
    }
}
