# Frankly

Android (Kotlin + Jetpack Compose) PDF editor.

## Features
- View PDFs (opens from file picker or "Open with" from any file manager)
- Highlight, freehand draw, add text, signature (draw), insert images
- "Edit text": cover existing text with a white box and type replacement text
- Page manager: reorder, delete, rotate pages
- Merge multiple PDFs
- Fill AcroForm fields (text + checkboxes)
- Undo / redo, Save As new PDF

## Build via GitHub Actions
1. Push this folder to a GitHub repo (branch `main`).
2. Actions tab -> "Build APK" runs automatically (or run manually).
3. Download `PDFStudio-debug-apk` artifact -> install the APK.

## Notes
- Engine: PdfRenderer (display) + pdfbox-android (saving, merge, forms).
- Annotations are baked into the PDF on Save / page ops / merge / form fill.
- Text edit is cover-and-replace, not true reflow editing of original text.
- Overlay text supports Latin characters only (standard Helvetica font).
